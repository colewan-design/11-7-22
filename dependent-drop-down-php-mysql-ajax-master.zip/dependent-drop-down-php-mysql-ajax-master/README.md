# dependent-drop-down-php-mysql-ajax
Dependent Drop Down list In PHP/MySQL using jQuery &amp; Ajax  
Follow this tutorial: https://www.youtube.com/watch?v=HRV2zEIMBqU
